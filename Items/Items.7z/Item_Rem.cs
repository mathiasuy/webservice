﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntidadesCompartidas;
namespace Items
{
    public class Item_Rem : Item
    {
        public Item_Rem(int NroLinDet,
                             string CodItem,
                             IndicadorFacturaType IndFact,
                             string NomItem,
                             string DscItem,
                             int Cantidad,
                             UnidadesDeMedida UniMed
                             )
            :base(NroLinDet,CodItem,IndFact,NomItem,DscItem,Cantidad,UniMed)
        {

        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}
