﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntidadesCompartidas;

namespace Items
{
    public class Item_Det_Fact : Item
    {
        public UnidadesDeMedida UniMed { get; set; }
        public double PrecioUnitario { get; set; }
        public double MontoItem
        {
            get
            {
                return PrecioUnitario * Cantidad;
            }
        }
        public Item_Det_Fact(int NroLinDet,
                             string CodItem,
                             IndicadorFacturaType IndFact,
                             string NomItem,
                             string DscItem,
                             int Cantidad,
                             UnidadesDeMedida UniMed,
                             double PrecioUnitario)
            :base(NroLinDet,CodItem,IndFact,NomItem,DscItem,Cantidad,UniMed)
        {
             this.PrecioUnitario = PrecioUnitario;
        }

        public override string ToString()
        {
            return 
                base.ToString() + " " + PrecioUnitario + " " + MontoItem;
        }
    }
}
